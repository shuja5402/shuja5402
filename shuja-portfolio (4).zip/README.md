# Syed Shujauddin | Portfolio

My personal portfolio website. It covers my background, experience, projects, skills, education, certifications and contact details, and has a built-in resume viewer.

Built with plain HTML, CSS and JavaScript. There is no build step and nothing to install.

## Folder structure

```
index.html        page markup
css/style.css     styles and light/dark theme
js/main.js        scroll effects, typing text, resume viewer
assets/           profile photo and resume
certificates/     certificate PDFs linked from my resume
```

## Run locally

Open `index.html` in a browser, or open the folder in VS Code and use the Live Server extension.

## Deploy on GitHub Pages

1. Put all the files in the root of the repository, so `index.html` sits next to the `css` and `js` folders.
2. Go to Settings > Pages.
3. Set the source to "Deploy from a branch", choose `main` and `/ (root)`, then save.
4. The site will be at `https://shuja5402.github.io/<repo-name>/`.

## Contact

- LinkedIn: https://www.linkedin.com/in/shuja5402
- GitHub: https://github.com/shuja5402
- Email: syedshujauddin5402@gmail.com
